import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteTask, fetchTaskWeather } from '../features/tasks/tasksSlice';

const TaskList = () => {
  const { tasks, weather, error } = useSelector((state) => state.tasks);
  const dispatch = useDispatch();

  const handleFetchWeather = (location) => {
    dispatch(fetchTaskWeather(location));
  };

  return (
    <div>
      <ul className="task-list">
        {tasks.map((task, index) => (
          <li key={index}>
            <span>
              {task.task} - {task.priority}
            </span>
            <button onClick={() => dispatch(deleteTask(index))}>Delete</button>
            <button onClick={() => handleFetchWeather('New York')}>Get Weather</button>
          </li>
        ))}
      </ul>
      {weather && <div>Weather: {weather.weather[0].description}</div>}
      {error && <div>Error: {error}</div>}
    </div>
  );
};

export default TaskList;