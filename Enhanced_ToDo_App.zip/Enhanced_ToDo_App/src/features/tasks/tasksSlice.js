import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchWeather } from '../../utils/api';

export const fetchTaskWeather = createAsyncThunk(
  'tasks/fetchWeather',
  async (location, { rejectWithValue }) => {
    try {
      const data = await fetchWeather(location);
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const tasksSlice = createSlice({
  name: 'tasks',
  initialState: {
    tasks: [],
    weather: null,
    error: null,
  },
  reducers: {
    addTask: (state, action) => {
      state.tasks.push(action.payload);
    },
    deleteTask: (state, action) => {
      state.tasks.splice(action.payload, 1);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTaskWeather.fulfilled, (state, action) => {
        state.weather = action.payload;
        state.error = null;
      })
      .addCase(fetchTaskWeather.rejected, (state, action) => {
        state.weather = null;
        state.error = action.payload;
      });
  },
});

export const { addTask, deleteTask } = tasksSlice.actions;
export default tasksSlice.reducer;