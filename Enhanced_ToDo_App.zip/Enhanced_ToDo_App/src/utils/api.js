import axios from 'axios';

const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';
//use your own API KEY
const API_KEY = 'your_api_key_here';

export const fetchWeather = async (location) => {
  try {
    const response = await axios.get(`${BASE_URL}?q=${location}&appid=${API_KEY}`);
    return response.data;
  } catch (error) {
    throw new Error('Error fetching weather data');
  }
};
